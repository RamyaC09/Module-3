package com.cg.SpringBootRestJpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBootRestJpa.bean.Product;
import com.cg.SpringBootRestJpa.dao.ProductDao;
//import com.cg.SpringBootRestJpa.exception.ProductException;

@Service
public class ProductServiceImpl implements ProductService
{
	@Autowired
	ProductDao productDao;
	
	@Override
	public List<Product> addProduct(Product pro) 
	{
		int amount = pro.getPrice() * pro.getQuantity();
		pro.setAmount(amount);
		
		productDao.save(pro);
		return productDao.findAll();
		// TODO Auto-generated method stub
	
	}
	
	@Override
	public Product getProductById(long id) 
	{
		return productDao.findById(id).get();
	
	}
	
	@Override
	public void deleteProduct(long id) 
	{
		productDao.deleteById(id);
	}
	
	@Override
	public List <Product> getAllProducts() 
	{
		return productDao.findAll();
	}
	
	@Override
	public List<Product> updateProduct(long id, Product pro)
	{
		
			Optional<Product> optional=productDao.findById(id);
			if(optional.isPresent())
			{
				Product product=optional.get();
				product.setName(pro.getName());
				product.setModel(pro.getModel());
				product.setPrice(pro.getPrice());
				productDao.save(product);
				return getAllProducts();
			}
			else
			{
				System.out.println("Product with Id"+id+" is not  existing please enter an valid id ");	
				return null;
			}

	}

	
}
